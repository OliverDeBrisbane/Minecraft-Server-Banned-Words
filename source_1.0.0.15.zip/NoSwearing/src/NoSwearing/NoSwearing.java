package NoSwearing;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NoSwearing extends JavaPlugin implements Listener {

	Logger logger;
	private PluginDescriptionFile pdfFile;
	private static Map<String, Object> counts = new HashMap<String, Object>();
	private static Map<String, Object> words = new HashMap<String, Object>();
	private static Map<String, Object> ReportedWords = new HashMap<String, Object>();
	private static Map<String, Object> finalWarnings = new HashMap<String, Object>();
	private static Map<String, Date> firstTimers = new HashMap<String, Date>();
	private static Map<String, Object> symbolList = new HashMap<String, Object>();
	private static Map<String, Date> playerMute = new HashMap<String, Date>();

	private ArrayList<String> allowList = new ArrayList<String>();
	private ArrayList<String> noWarn = new ArrayList<String>();

	private static Map<String, String> lastWord = new HashMap<String, String>();

	private static Map<String, messageQueue> messagingQueue;

	private int wordCount = 0;
	private boolean showMessageOnLogin;
	private boolean blockURLSandIP = false;
	private String onLoginMessage;
	private boolean showWarnings;
	private String onWarning;
	private boolean kick;
	private int kickOnWarning;
	private boolean censor = false;
	private int warnings;
	private int muteOffenders = 0;
	private String onFinalWarning;
	private String onFinalMessage;
	private boolean ignoreOps;
	private boolean overRideKick = false;
	private String customCommand;
	private boolean disableWarnings = false;

	private ArrayList<String> censorString = new ArrayList<String>();

	// private String censorString;
	private boolean advanced;
	private boolean InventoryCheck = true;
	private boolean messageQueing = true;
	private int queStack = 10;
	private int firstTimeMax = 3;
	private boolean vowelCheck = true;
	private boolean symbols = true;
	private String warnOnSymbols = "warn";
	private boolean censorRepeating = false;
	private boolean allowReport = false;

	File file = null;
	YamlConfiguration fileConfig = null;

	@EventHandler
	public void playerJoin(PlayerJoinEvent event) {

		String player = event.getPlayer().getName();

		file = new File("plugins/NoSwearing256/users/" + player + ".yml");
		fileConfig = YamlConfiguration.loadConfiguration(file);

		if (!file.exists()) {

			if (counts.containsKey(player)) {
				fileConfig.set("swearCount", counts.get(player));
			} else {
				fileConfig.set("swearCount", 0);
			}

			if (finalWarnings.containsKey(player)) {
				fileConfig.set("finalCount", finalWarnings.get(player));
			} else {
				fileConfig.set("finalCount", 0);
			}
			fileConfig.set("words", null);

			try {
				fileConfig.save(file);
			} catch (IOException e) {

				e.printStackTrace();
			}

		} else {
			counts.remove(player);
			finalWarnings.remove(player);

			counts.put(player, fileConfig.getInt("swearCount"));
			finalWarnings.put(player, fileConfig.getInt("finalCount"));
			// more....
		}

		if (messageQueing) {

			createQueue(player);
		}

		if (event.getPlayer().isOp() && allowReport) {

			if (ReportedWords.size() > 0) {

				sendToPlayer(
						"There are ".concat(
								String.valueOf(ReportedWords.size())).concat(
								" words flagged for review."), player);
			}
		}

		if (!(ignoreOps && event.getPlayer().isOp())) {

			// On player join send them the message from config.yml
			if (showMessageOnLogin == true) {
				sendToPlayer(onLoginMessage, player);
			}

			if (noWarn.contains(player)) {

				// On player join send them warning information from config.yml
				if (showWarnings == true) {
					sendToPlayer("You can not receive warnings.", player);
				}

			} else {

				// On player join send them warning information from config.yml
				if (showWarnings == true) {
					sendToPlayer(getWarningsString(player), player);
				}
			}
		}
	}

	private void createQueue(String player) {
		messagingQueue.put(player, new messageQueue(queStack));
		sendWarningToConsole("Messaging queue created for ".concat(player));
	}

	@EventHandler(priority = EventPriority.HIGHEST)
	public void onPreLogin(AsyncPlayerPreLoginEvent event) {

		boolean oldPlayer = getServer().getOfflinePlayer(event.getName())
				.hasPlayedBefore();

		if (!oldPlayer) {
			firstTimers.put(event.getName(), new Date());
		}
		event.allow();
		return;
	}

	@EventHandler
	public void onPlayerLogout(PlayerQuitEvent event) {
		firstTimers.remove(event.getPlayer().getName());
		messagingQueue.remove(event.getPlayer().getName());

		String player = event.getPlayer().getName();

		file = new File("plugins/NoSwearing256/users/" + player + ".yml");
		fileConfig = YamlConfiguration.loadConfiguration(file);

		if (counts.containsKey(player)) {
			fileConfig.set("swearCount", counts.get(player));
		} else {
			fileConfig.set("swearCount", 0);
		}

		if (finalWarnings.containsKey(player)) {
			fileConfig.set("finalCount", finalWarnings.get(player));
		} else {
			fileConfig.set("finalCount", 0);
		}

		// set words

		try {
			fileConfig.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}

		counts.remove(player);
		finalWarnings.remove(player);

	}

	@EventHandler
	public void onPlayerCommandPreprocessEvent(
			PlayerCommandPreprocessEvent event) {
		String cmd = event.getMessage().toLowerCase();
		String player = event.getPlayer().getName();

		if (!(ignoreOps && event.getPlayer().isOp())) {

			if (cmd.contains("nick") || cmd.matches(".*?\\bme\\b.*?")
					|| cmd.matches(".*?\\bmsg\\b.*?")
					|| cmd.matches(".*?\\bwisper\\b.*?")
					|| cmd.matches(".*?\\btell\\b.*?")
					|| cmd.matches(".*?\\bbroadcast\\b.*?")
					|| cmd.matches(".*?\\bserver\\b.*?")) {

				String[] result = isInappropriate(cmd, player);
				if (!result[0].isEmpty()) {

					if (censor) {

						event.setMessage(result[0]);

					} else {
						event.setCancelled(true);
					}

					if (result[2].equals("warn")
							|| (firstTimers.containsKey(player) && firstTimeMax > -1)
							&& !noWarn.contains(player)) {
						addWarning(player, result[1]);
					}
				}
			}
		}
	}

	@EventHandler
	public void onChat(AsyncPlayerChatEvent event) {

		String player = event.getPlayer().getName();
		String msg = event.getMessage().toLowerCase();

		if (playerMute.containsKey(player)) {

			Date playerOffence = playerMute.get(player);

			if (new Date().getTime() - playerOffence.getTime() < (muteOffenders * 1000)) {
				sendToPlayer("You have been muted temporarily for swearing.",
						player);
				sendWarningToConsole("[Muted] " + player + ": " + msg);
				event.setCancelled(true);
				return;
			} else {
				playerMute.remove(player);
			}
		}

		if (!(ignoreOps && event.getPlayer().isOp())) {

			messageQueue queue = null;

			if (messageQueing) {

				// Block single letter messages
				if (msg.matches("^[A-Za-z]$")) {
					event.setCancelled(true);
				}

				queue = messagingQueue.get(player);

				if (queue == null) {

					createQueue(player);
					queue = messagingQueue.get(player);

				}
				queue.setMessages(msg);

				String[] queueResult = isInappropriate(queue.getText(), player);
				if (!queueResult[0].isEmpty()) {

					if (censor) {

						sendSevereToConsole("[CHAT] ".concat(player)
								.concat(": ").concat(queueResult[1]));

						// Re-enable the event and display censor string
						event.setCancelled(false);

						String lineResult[] = isInappropriate(queue.getLast(),
								player);

						if (lineResult[0].equals("")) {
							event.setMessage(getCensorString(player));
						} else {
							event.setMessage(lineResult[0]);
						}
						
						for (Player ply : Bukkit.getOnlinePlayers())
						{
							if (ply.hasPermission("ns.see"))
							{
								sendToPlayer(ChatColor.RED + "Censored: ".concat(queueResult[1]), ply.getName());
							}
						}

					} else {

						event.setCancelled(true);
					}

					queue.clear();
					if (queueResult[2].equals("warn")
							&& !noWarn.contains(player)
							|| (firstTimers.containsKey(player) && firstTimeMax > -1)) {
						addWarning(player, queueResult[1]);
					} else if (noWarn.contains(player)
							|| queueResult[2].equals("info")) {
						if (allowReport) {

							String review = lastWord.get(player);

							sendToPlayer(ChatColor.WHITE + "Type "
									+ ChatColor.YELLOW + "/ns report"
									+ ChatColor.WHITE + " to flag "
									+ ChatColor.RED + review + ChatColor.WHITE
									+ " for review.", player);
						}
					}
				} else {

					// sendWarningToConsole("empty");
				}
			} else {
				String[] result = isInappropriate(msg, player);

				if (!result[0].isEmpty()) {

					sendSevereToConsole("[CHAT] ".concat(player).concat(": ")
							.concat(result[1]));

					if (censor) {

						event.setMessage(result[0]);
						
						for (Player ply : Bukkit.getOnlinePlayers())
						{
							if (ply.hasPermission("ns.see"))
							{
								sendToPlayer(ChatColor.RED + "Censored: ".concat(result[1]), ply.getName());
							}
						}

					} else {
						event.setCancelled(true);
					}

					if (result[2].equals("warn") && !noWarn.contains(player)) {
						addWarning(player, result[1]);
					} else if (noWarn.contains(player)
							|| result[2].equals("info")) {
						if (allowReport) {

							String review = lastWord.get(player);

							sendToPlayer(ChatColor.WHITE + "Type "
									+ ChatColor.YELLOW + "/ns report"
									+ ChatColor.WHITE + " to flag "
									+ ChatColor.RED + review + ChatColor.WHITE
									+ " for review.", player);	
						}
					}
				}
			}
		}
	}

	// Monitor sign changes for restricted words
	@EventHandler
	public void onSignChange(final SignChangeEvent event) {

		String[] lines = event.getLines();
		int index = 0;
		boolean warn = false;
		String warnString = "";

		if (!(ignoreOps && event.getPlayer().isOp())) {

			outer: for (String line : lines) {

				String result[] = isInappropriate(line, event.getPlayer()
						.getDisplayName());

				if (!result[0].isEmpty()) {

					warnString += result[1];
					warn = true;

					sendSevereToConsole("[SIGN]"
							.concat(event.getPlayer().getName()).concat(": ")
							.concat(result[1]));

					if (censor) {

						event.setLine(index, result[0]);

					} else {

						event.setCancelled(true);
						event.getBlock().breakNaturally();
						break outer;
					}

					String player = event.getPlayer().getName();

					if ((result[2].equals("warn") && !noWarn.contains(player))
							|| (firstTimers.containsKey(event.getPlayer()) && firstTimeMax > -1)) {
						warn = true;
					} else if (noWarn.contains(player)) {
						if (allowReport) {

							String review = lastWord.get(player);

							sendToPlayer(ChatColor.WHITE + "Type "
									+ ChatColor.YELLOW + "/ns report"
									+ ChatColor.WHITE + " to flag "
									+ ChatColor.RED + review + ChatColor.WHITE
									+ " for review.", player);

							if (lastWord.containsKey(player)) {
								lastWord.remove(player);
								lastWord.put(player, result[1]);
							} else {
								lastWord.put(player, result[1]);
							}
						}
					}
				}
				index++;
			}
		}

		if (warn) {
			addWarning(event.getPlayer().getName(), warnString);
		}
	}

	public String[] isInappropriate(String msg, String player) {

		msg = msg.toLowerCase();
		msg = msg.replace("�", "");

		String result[] = { advancedCheck(msg), "", "" };
		String lastOffense = "";

		if (msg != null) {

			Map<String, Object> tempMap = new HashMap<String, Object>();

			// This section detects words with symbols in place
			if (symbols) {
				if (result[0]
						.matches(".*?\\b\\p{L}*[\\p{S}\\p{P}]((\\p{L}[\\p{P}\\p{S}])|([\\p{P}\\p{S}]*\\p{L})|(\\p{L}))+\\b.*?")) {

					String regex = "\\b\\p{L}*[\\p{S}\\p{P}]((\\p{L}[\\p{P}\\p{S}])|([\\p{P}\\p{S}]*\\p{L})|(\\p{L}))+\\b";
					Pattern wordRegex = Pattern.compile(regex);

					Matcher m = wordRegex.matcher(result[0]);

					ArrayList<String> mResult = new ArrayList<String>();

					while (m.find()) {

						mResult.add(m.group().toLowerCase());
					}

					for (String sResult : mResult) {
						boolean isValid = true;

						if (Bukkit.getPlayer(sResult) != null) {
							isValid = false;
						}

						// Words with one apostrophe only.
						if (sResult
								.matches("\\b\\w+(('\\w\\b)|('\\w\\w\\b)|('[tsdm]\\b)|(\\w'(?!\\w)))")) {

							isValid = false;
						}

						// Words with color codes.
						if (sResult.matches(".*?(&(\\d|[a-k])){1,}.*?")) {

							isValid = false;
						}

						if (allowList.contains(sResult)) {

							isValid = false;
						}

						// Slash
						if (sResult.matches("[a-z]{3,}/[a-z]{2,}")) {
							isValid = false;
						}

						// Underscore
						if (sResult.matches("([a-z]{1,}_){1,}[a-z]{5,}")) {
							isValid = false;
						}

						// Dash
						if (sResult.matches("[a-z]{2,}-[a-z]{3,}")) {
							isValid = false;
						}

						// Words with http address.
						if (sResult
								.matches("^((ftp|http|https):\\/\\/)?([a-zA-Z0-9]{2,}+(\\.[a-zA-Z0-9]{2,}+)+.*)$")) {

							isValid = false;
						}
						
						// IP address
						if (sResult
								.matches("\\/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$\\/")) {

							isValid = false;
						}

						if (isValid) {
							result[1] += "'".concat(
									sResult.replaceAll("[a-z0-9A-Z]", ""))
									.concat("' is not allowed within "
											.concat(sResult));
							result[0] = result[0].replaceAll(regex,
									getCensorString(player));
							result[2] = warnOnSymbols;
							lastOffense = sResult;

							/*
							 * String wordToReplace = sResult.replaceAll(".",
							 * "[dot]");
							 * 
							 * if (symbolList.containsKey(wordToReplace)) { int
							 * count = (Integer) symbolList .get(wordToReplace);
							 * symbolList.remove(wordToReplace);
							 * symbolList.put(wordToReplace, ++count);
							 * 
							 * } else { symbolList.put(wordToReplace, 1);
							 * 
							 * }
							 */
						}
					}
				}
			}
			
			if (blockURLSandIP)
			{
				String regexIP = "([012]?\\d{1,2})(\\.[012]?\\d{1,2}){3}(:(\\d{1,5}))?";
				String regexURI = ".*([\\w-]+\\.)+[a-z]{2,5}(/[\\w-]+)*";
				
				// Words with IP
				if (msg
						.matches(regexIP)) {
	
					result[1] += "IP is not allowed.";
					result[0] = result[0].replaceAll(regexIP,
							"[IP]");
					result[2] = warnOnSymbols;
					lastOffense = "IP";
				}

				// Words with http address
				if (msg
						.matches(regexURI)) {
	
					result[1] += "URL is not allowed.";
					result[0] = result[0].replaceAll(regexURI,
							"[URL]");
					result[2] = warnOnSymbols;
					lastOffense = "URL";
				}
			}

			ArrayList<String> catcher = new ArrayList<String>();

			// Installed word list catcher
			for (Map.Entry<String, Object> wordKey : words.entrySet()) {

				int count = 0;// (Integer) wordKey.getValue();
				String thisWord = wordKey.getKey();

				String words[] = { thisWord, null };

				if (vowelCheck && !thisWord.contains("/i")) {
					words[1] = thisWord.replaceAll("[aeiou](?!\\b)", "");
				}

				if (thisWord.contains("/i")) {
					words[0] = thisWord.replaceAll("/i", "");
				}

				boolean disableBuilder = false;
				for (String word : words) {

					if (word != null) {

						if (word.contains("!")) {
							String wordToMatch = word.substring(0,
									word.indexOf("!"));
							String letterToNotMatch = word.substring(
									word.indexOf("!") + 1, word.length());

							String matcher = wordToMatch;
							if (!disableBuilder) {
								matcher = regexBuild(wordToMatch);
							}

							String wordRegex = "\\b".concat(matcher)
									.concat("((?!").concat(letterToNotMatch)
									.concat("))");

							String regex = ".*?".concat(wordRegex)
									.concat(".*?");

							while (result[0].matches(regex)) {

								count++;
								result[0] = result[0].replaceAll(regex,
										getCensorString(player));
								result[1] += wordToMatch + " ";

								catcher.add(word);

								tempMap.remove(thisWord);
								tempMap.put(thisWord, count);
								result[2] = "warn";
								lastOffense = wordToMatch;
							}
							;
						}

						// Match whole word only
						else {

							if (advanced) {
								// Remove all symbols
								words[0] = words[0].replaceAll(
										"(?<=\\w)[^a-zA-Z0-9*:()\\s]+(?=\\w)",
										"");
							}

							if (word.startsWith("/b") && word.endsWith("/b")) {

								String wordToMatch = word.substring(2,
										word.length() - 2);

								String matcher = wordToMatch;
								if (!disableBuilder) {
									matcher = regexBuild(wordToMatch);
								}

								String wordRegex = "\\b".concat(matcher)
										.concat("\\b");
								String regex = ".*?".concat(wordRegex).concat(
										".*?");

								while (result[0].matches(regex)) {

									count++;

									catcher.add(word);

									result[0] = result[0].replaceAll(wordRegex,
											getCensorString(player));
									result[1] += wordToMatch + " ";

									tempMap.remove(thisWord);
									tempMap.put(thisWord, count);
									result[2] = "warn";
									lastOffense = wordToMatch;
								}
								;
							}

							else if (word.endsWith("/b")) {
								String wordToMatch = word.substring(0,
										word.length() - 2);

								String matcher = wordToMatch;
								if (!disableBuilder) {
									matcher = regexBuild(wordToMatch);
								}

								String wordRegex = matcher.concat("\\b");
								String regex = ".*?".concat(wordRegex).concat(
										".*?");

								while (result[0].matches(regex)) {

									count++;

									catcher.add(word);

									result[0] = result[0].replaceAll(wordRegex,
											getCensorString(player));
									result[1] += wordToMatch + " ";

									tempMap.remove(thisWord);
									tempMap.put(thisWord, count);
									result[2] = "warn";
									lastOffense = wordToMatch;
								}
								;
							}

							else if (word.startsWith("/b")) {
								String wordToMatch = word.substring(2,
										word.length());

								String matcher = wordToMatch;
								if (!disableBuilder) {
									matcher = regexBuild(wordToMatch);
								}

								String wordRegex = "\\b".concat(matcher);
								String regex = ".*?".concat(wordRegex).concat(
										".*?");

								while (result[0].matches(regex)) {

									count++;

									catcher.add(word);

									result[0] = result[0].replaceAll(wordRegex,
											getCensorString(player));
									result[1] += wordToMatch + " ";

									tempMap.remove(thisWord);
									tempMap.put(thisWord, count);
									result[2] = "warn";
									lastOffense = wordToMatch;
								}
								;
							}

							else {

								String matcher = word;
								if (!disableBuilder) {
									matcher = regexBuild(word);
								}

								String regex = ".*?".concat(matcher).concat(
										".*?");

								while (result[0].matches(regex)) {

									count++;

									catcher.add(word);

									result[0] = result[0].replaceAll(matcher,
											getCensorString(player));
									result[1] += word + " ";

									tempMap.remove(thisWord);
									tempMap.put(thisWord, count);
									result[2] = "warn";
									lastOffense = word;
								}
								;
							}
						}

						if (censorRepeating && !catcher.contains(word)) {
							// Repeating characters catcher.
							// String rRegex = "[a-z]*([a-z])\\1{3,}[a-z]*";

							String tWord = word.replaceAll("/b", "");

							String rRegex = regexBuildRepeat(tWord);

							if (word.startsWith("/b")) {
								rRegex = ".*?\\b".concat(rRegex);
							}
							if (word.endsWith("/b")) {
								rRegex = rRegex.concat("\\b.*?");
							}

							Pattern rPattern = Pattern.compile(rRegex);
							Matcher rMatcher = rPattern.matcher(msg);

							while (rMatcher.find()) {

								result[1] += rMatcher.group();
								result[0] = result[0].replaceAll(rRegex,
										getCensorString(player));
								result[2] = warnOnSymbols;
								lastOffense = word;
							}
						}

					}
					disableBuilder = true;
				}
			}

			for (Map.Entry<String, Object> wordKey : tempMap.entrySet()) {
				String key = wordKey.getKey();
				int counter = Integer.valueOf(words.get(key).toString())
						+ Integer.valueOf(wordKey.getValue().toString());

				words.remove(key);
				words.put(key, counter);
			}

			if (result[1].equals("")) {
				result[0] = "";
			} else {
				if (lastWord.containsKey(player)) {
					lastWord.remove(player);
					lastWord.put(player, lastOffense);
				} else {
					lastWord.put(player, lastOffense);
				}
				saveWords();
			}

			result[1] = result[1].toUpperCase();
			return result;

		} else {
			result[0] = "";
			return result;
		}
	}

	public String advancedCheck(String msg) {

		String newString = msg;

		if (advanced && newString != null) {

			newString = newString.replaceAll("@", "a");
			newString = newString.replaceAll("\\$", "s");
			newString = newString.replaceAll("[0-9]", "");

		}
		return newString;
	}

	public String regexBuild(String msg) {
		char[] chars = msg.toCharArray();
		StringBuilder sb = new StringBuilder();

		if (advanced) {
			for (char Char : chars) {
				sb.append(Char);
				sb.append("[ ]*");
			}
			return sb.toString();
		}
		return msg;
	}

	public String regexBuildRepeat(String msg) {
		char[] chars = msg.toCharArray();
		StringBuilder sb = new StringBuilder();

		if (advanced) {
			for (char Char : chars) {
				sb.append(Char);
				sb.append("+");
			}
			return sb.toString();
		}
		return msg;
	}

	// Handle the enabling of the plugin
	@Override
	public void onEnable() {

		// Create a default config file if none is present.
		this.saveDefaultConfig();

		logger = Logger.getLogger("Minecraft");

		// Get the plugin description data
		pdfFile = getDescription();

		messagingQueue = new HashMap<String, messageQueue>();

		// Load the Config data
		loadMyConfig();

		// Register a new listener for player login
		Bukkit.getPluginManager().registerEvents(this, this);

		// This writes that data to the console for log purposes
		sendWarningToConsole(" version " + pdfFile.getVersion()
				+ " has been enabled!");

	}

	// Handle the disabling of the plugin
	@Override
	public void onDisable() {

		if (messageQueing) {
			for (Player player : Bukkit.getOnlinePlayers()) {
				messagingQueue.remove(player.getName());
			}
		}

		// This writes that data to the console for log purposes
		sendWarningToConsole(" version " + pdfFile.getVersion()
				+ " has been disabled!");

		saveMyConfig();
	}

	private String getCensorString(String player) {

		int count = censorString.size();

		int rand = (int) (Math.random() * ((count)));

		if (rand < 0)
			rand = 0;

		if (rand > count)
			rand = count;

		String result = censorString.get(rand);

		if (result.contains("%name%")) {

			result.replace("%name%", player);
		}
		return result + " ";
	}

	// Load user data from the config file.
	private void loadMyConfig() {

		loadStatic();

		//words = this.getConfig().getConfigurationSection("Words")
		//		.getValues(true);

		file = new File("plugins/NoSwearing256/words.yml");
		fileConfig = YamlConfiguration.loadConfiguration(file);

		if (file.exists()) {

			try {
				words = (Map<String, Object>) fileConfig
						.getConfigurationSection("Words").getValues(false);
				allowList = (ArrayList<String>) fileConfig
						.getStringList("Allow");
				ReportedWords = (Map<String, Object>) fileConfig
						.getConfigurationSection("ReportedWords").getValues(
								false);
			} catch (Exception ex) {
				sendWarningToConsole(ex.getMessage());
			}

			sendWarningToConsole("Words loaded:" + String.valueOf(words.size()));
			sendWarningToConsole("Allowed Words:" + String.valueOf(allowList.size()));
			sendWarningToConsole("Reported Words:" + String.valueOf(ReportedWords.size()));

		}

		censorString = new ArrayList<String>(this.getConfig().getStringList(
				"censorString"));
		noWarn = new ArrayList<String>(this.getConfig().getStringList("noWarn"));
			sendSevereToConsole(String.valueOf(noWarn.size()).concat(" players will not be warned."));
		
		// censorString = this.getConfig().getString("censorString");

		wordCount = 0;
		for (@SuppressWarnings("unused")
		Map.Entry<String, Object> word : words.entrySet()) {
			wordCount++;
		}

		if (!this.getConfig().isSet("SymbolList")) {
			symbolList = this.getConfig().getConfigurationSection("SymbolList")
				.getValues(true);
			sendWarningToConsole("Loaded symbol list");
		}
	}

	private void loadStatic() {

		StringBuilder created = new StringBuilder();

		// Check if missing
		if (!this.getConfig().isSet("blockURLSandIP")) {
			created.append("blockURLSandIP ");
			this.getConfig().set("blockURLSandIP", false);
		}
		blockURLSandIP = this.getConfig().getBoolean("blockURLSandIP");
		
		// Check if missing
		if (!this.getConfig().isSet("showMessageOnLogin")) {
			created.append("showMessageOnLogin ");
			this.getConfig().set("showMessageOnLogin", false);
		}
		showMessageOnLogin = this.getConfig().getBoolean("showMessageOnLogin");

		// Check if missing
		if (!this.getConfig().isSet("onLoginMessage")) {
			created.append("onLoginMessage ");
			this.getConfig().set("onLoginMessage",
					"This server is monitored for swearing.");
		}
		onLoginMessage = this.getConfig().getString("onLoginMessage");

		// Check if missing
		if (!this.getConfig().isSet("showWarnings")) {
			created.append("showWarnings ");
			this.getConfig().set("showWarnings", true);
		}
		showWarnings = this.getConfig().getBoolean("showWarnings");

		// Check if missing
		if (!this.getConfig().isSet("disableWarnings")) {
			created.append("disableWarnings ");
			this.getConfig().set("disableWarnings", false);
		}
		disableWarnings = this.getConfig().getBoolean("disableWarnings");
		
		// Check if missing
		if (!this.getConfig().isSet("censorRepeating")) {
			created.append("censorRepeating ");
			this.getConfig().set("censorRepeating", false);
		}
		censorRepeating = this.getConfig().getBoolean("censorRepeating");

		// Check if missing
		if (!this.getConfig().isSet("onWarning")) {
			created.append("onWarning ");
			this.getConfig().set("onWarning",
					"is not an allowed word. This is a warning!");
		}
		onWarning = this.getConfig().getString("onWarning");

		// Check if missing
		if (!this.getConfig().isSet("kick")) {
			created.append("kick ");
			this.getConfig().set("kick", true);
		}
		kick = this.getConfig().getBoolean("kick");

		// Check if missing
		if (!this.getConfig().isSet("kickOnWarning")) {
			created.append("kickOnWarning ");
			this.getConfig().set("kickOnWarning", 2);
		}
		kickOnWarning = this.getConfig().getInt("kickOnWarning");

		// Check if missing
		if (!this.getConfig().isSet("warnings")) {
			created.append("warnings ");
			this.getConfig().set("warnings", 3);
		}
		warnings = this.getConfig().getInt("warnings");

		// Check if missing
		if (!this.getConfig().isSet("MuteOffendersTime")) {
			created.append("MuteOffendersTime ");
			this.getConfig().set("MuteOffendersTime", 0);
		}
		muteOffenders = this.getConfig().getInt("MuteOffendersTime");

		// Check if missing
		if (!this.getConfig().isSet("censor")) {
			created.append("censor ");
			this.getConfig().set("censor", true);
		}
		censor = this.getConfig().getBoolean("censor");

		// Check if missing
		if (!this.getConfig().isSet("onFinalWarning")) {
			created.append("showMessageOnLogin ");
			this.getConfig().set("onFinalWarning", "kick");
		}
		onFinalWarning = this.getConfig().getString("onFinalWarning");

		// Check if missing
		if (!this.getConfig().isSet("onFinalMessage")) {
			created.append("onFinalMessage ");
			this.getConfig().set("onFinalMessage",
					"You have reached the maximum number of warnings.");
		}
		onFinalMessage = this.getConfig().getString("onFinalMessage");

		// Check if missing
		if (!this.getConfig().isSet("ignoreOps")) {
			created.append("ignoreOps ");
			this.getConfig().set("ignoreOps", true);
		}
		ignoreOps = this.getConfig().getBoolean("ignoreOps");

		// Check if missing
		if (!this.getConfig().isSet("advanced")) {
			created.append("advanced ");
			this.getConfig().set("advanced", true);
		}
		advanced = this.getConfig().getBoolean("advanced");

		// Check if missing
		if (!this.getConfig().isSet("overrideKick")) {
			sendWarningToConsole("New configuration values missing.");
			this.getConfig().set("overrideKick", false);
			this.getConfig().set("customCommand", "jail %name% jail");
			created.append("overrideKick customCommand ");
		}
		overRideKick = this.getConfig().getBoolean("overrideKick");
		customCommand = this.getConfig().getString("customCommand");

		// Check if missing
		if (!this.getConfig().isSet("symbols")) {
			created.append("symbols ");
			this.getConfig().set("symbols", true);
		}
		symbols = this.getConfig().getBoolean("symbols");

		// Check if missing
		if (!this.getConfig().isSet("symbolsAction")) {
			created.append("symbolsAction ");
			this.getConfig().set("symbolsAction", "warn");
		}
		warnOnSymbols = this.getConfig().getString("symbolsAction")
				.toLowerCase();

		// Check if missing
		if (!this.getConfig().isSet("inventoryCheck")) {
			created.append("inventoryCheck ");
			this.getConfig().set("inventoryCheck", true);
		}
		InventoryCheck = this.getConfig().getBoolean("inventoryCheck");

		// Check if missing
		if (!this.getConfig().isSet("messageQueing")) {
			created.append("messageQueing ");
			this.getConfig().set("messageQueing", true);
		}
		messageQueing = this.getConfig().getBoolean("messageQueing");

		// Check if missing
		if (!this.getConfig().isSet("queStack")) {
			created.append("queStack ");
			this.getConfig().set("queStack", 10);
		}
		queStack = this.getConfig().getInt("queStack");

		// Check if missing
		if (!this.getConfig().isSet("firstTimers")) {
			created.append("firstTimers ");
			this.getConfig().set("firstTimers", false);
		}
		firstTimeMax = this.getConfig().getInt("firstTimers");

		// Check if missing
		if (!this.getConfig().isSet("removeVowels")) {
			created.append("removeVowels ");
			this.getConfig().set("removeVowels", false);
		}
		vowelCheck = this.getConfig().getBoolean("removeVowels");

		// Check if missing
		if (!this.getConfig().isSet("allowReport")) {
			created.append("allowReport ");
			this.getConfig().set("allowReport", true);
		}
		allowReport = this.getConfig().getBoolean("allowReport");

		if (created.length() > 0) {
			saveMyConfig();
			sendWarningToConsole("Missing configuration values have been added and set to default.\n"
					+ created.toString());
		}
	}

	// Save the userdata to the config file.
	private void saveMyConfig() {

		this.reloadConfig();

		//this.getConfig().createSection("Offenders", counts);
		//this.getConfig().createSection("FinalWarnings", finalWarnings);

		StringBuilder removal = new StringBuilder();

		// Delete old sections that are no longer needed.
		if (this.getConfig().isSet("Words")) {
			removal.append("Words ");
			this.getConfig().set("Words", null);
		}
		if (this.getConfig().isSet("ReportedWords")) {
			removal.append("ReportedWords ");
			this.getConfig().set("ReportedWords", null);
		}
		if (this.getConfig().isSet("Allow")) {
			removal.append("Allow ");
			this.getConfig().set("Allow", null);
		}
		if (this.getConfig().isSet("Offenders")) {
			removal.append("Offenders ");
			this.getConfig().set("Offenders", null);
		}
		if (this.getConfig().isSet("FinalWarnings")) {
			removal.append("FinalWarnings ");
			this.getConfig().set("FinalWarnings", null);
		}

		if (removal.length() > 0) {
			sendWarningToConsole("Removed the following configuration sections for being obsolete: "
					+ removal.toString());
		}

		saveWords();

		this.getConfig().createSection("SymbolList", symbolList);
		this.getConfig().set("noWarn", noWarn);
		this.saveConfig();

		for (Player ply : Bukkit.getOnlinePlayers()) {

			String player = ply.getName();
			file = new File("plugins/NoSwearing256/users/" + player + ".yml");
			fileConfig = YamlConfiguration.loadConfiguration(file);

			if (counts.containsKey(player)) {
				fileConfig.set("swearCount", counts.get(player));
			}

			if (finalWarnings.containsKey(player)) {
				fileConfig.set("finalCount", finalWarnings.get(player));
			}

			fileConfig.set("words", null);

			try {
				fileConfig.save(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void saveWords() {
		file = new File("plugins/NoSwearing256/words.yml");
		fileConfig = YamlConfiguration.loadConfiguration(file);

		fileConfig.set("Words", words);
		fileConfig.set("ReportedWords", ReportedWords);
		fileConfig.set("Allow", allowList);

		try {
			fileConfig.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Get the string to send to the player showing warnings.
	private String getWarningsString(String player) {

		int count = getWarnings(player);
		StringBuilder sb = new StringBuilder();

		if (count >= 0) {

			sb.append("You have received ");
			sb.append(count);
			sb.append(" out of ");
			sb.append(warnings);
			sb.append(" warnings.");
		}
		else
		{
			sb.append("Player data not available.");			
		}
		return sb.toString();
	}

	// Get the number of warnings the player has received.
	private int getWarnings(String player) {
		int count = -1;
		if (counts.containsKey(player)) {
			count = (Integer) counts.get(player);
		}
		return count;
	}

	// Get the number of warnings the player has received.
	private int getFinalWarnings(String player) {
		int count = 0;
		if (finalWarnings.containsKey(player)) {
			count = (Integer) finalWarnings.get(player);
		}
		return count;
	}

	// Subroutine to increment the players warning level. If the player
	// is not present, they are added to the list.
	private void addWarning(String player, String msg) {

		int count = 1;
		final Player thisPlayer = Bukkit.getPlayer(player);

		if (disableWarnings)
			return;
		
		if (muteOffenders > 0) {
			playerMute.put(player, new Date());
		}

		if (allowReport) {

			String review = lastWord.get(player);

			sendToPlayer(ChatColor.WHITE + "Type " + ChatColor.GREEN
					+ "/ns report" + ChatColor.WHITE + " to flag "
					+ ChatColor.BLUE + review + ChatColor.WHITE
					+ " for review.", player);
		}

		if (counts.containsKey(player)) {
			count = getWarnings(player) + 1;
			counts.remove(player);
			counts.put(player, count);

		} else {
			counts.put(player, 1);
		}

		if (firstTimeMax > -1) {
			if (firstTimers.containsKey(player)) {
				Date end = new Date();
				Date start = firstTimers.get(player);
				long minutes = (((end.getTime() - start.getTime()) / 1000 / 60));

				if (minutes < firstTimeMax) {

					sendWarningToConsole("New player ".concat(player)
							.concat(" was banned for swearing within ")
							.concat(String.valueOf(minutes))
							.concat(" minutes."));
					sendToAll(ChatColor.RED
							+ player.concat(" was banned for swearing."));

					if (!overRideKick) {
						kickPlayer("Swearing", thisPlayer);
					} else {
						commandPlayer("Swearing", thisPlayer);
					}

					thisPlayer.setBanned(true);
				}
			}
		}

		if (count >= warnings) {

			String cmd = onFinalWarning;

			int finalCount = getFinalWarnings(player);
			if (finalCount > 0) {

				finalWarnings.remove(player);

			}

			finalCount++;
			finalWarnings.put(player, finalCount);

			if (cmd.equals("kick") || cmd.equals("ban") || cmd.equals("custom")) {

				counts.remove(player);
				if (thisPlayer.isOnline()) {

					if (!overRideKick) {
						kickPlayer(ChatColor.RED + onFinalMessage, thisPlayer);
					} else {
						commandPlayer(ChatColor.RED + onFinalMessage,
								thisPlayer);
					}

					sendToAll(ChatColor.RED
							+ player.concat(" was kicked for final warning."));
				}
			}

			if (cmd.equals("ban")) {

				kickPlayer(ChatColor.RED + onFinalMessage, thisPlayer);

				sendToAll(ChatColor.RED
						+ player.concat(" was banned for final warning."));

				thisPlayer.setBanned(true);
			}

		} else if (count == kickOnWarning) {
			if (kick == true) {

				sendToAll(ChatColor.RED
						+ player.concat(" was kicked as a warning."));

				if (thisPlayer.isOnline()) {

					if (!overRideKick) {
						kickPlayer("'" + msg + "' " + onWarning, thisPlayer);
					} else {
						commandPlayer("'" + msg + "' " + onWarning, thisPlayer);
					}
				}
			}
		} else {

			sendToPlayer("'" + msg + "' " + onWarning, player);

		}

		saveMyConfig();

	}

	private void kickPlayer(final String msg, final Player thisPlayer) {

		this.getServer().getScheduler()
				.scheduleSyncDelayedTask(this, new Runnable() {
					@Override
					public void run() {
						thisPlayer.kickPlayer(msg);
					}
				}, 10L);

	}

	private void commandPlayer(final String msg, final Player thisPlayer) {

		final String command = customCommand.replace("%name%",
				thisPlayer.getName());
		final CommandSender mycmd = this.getServer().getConsoleSender();

		this.getServer().getScheduler()
				.scheduleSyncDelayedTask(this, new Runnable() {
					@Override
					public void run() {

						Bukkit.getServer().dispatchCommand(mycmd, command);
						sendWarningToConsole("Issuing command: " + command);

					}
				}, 10L);

	}

	@EventHandler
	public void onInventoryAdd(InventoryCloseEvent event) {

		if (!(ignoreOps && event.getPlayer().isOp())) {

			Player player = (Player) event.getPlayer();
			String reason = event.getInventory().getName();
			PlayerInventory inventory = (PlayerInventory) player.getInventory();

			if (InventoryCheck) {

				if (reason.equals("Repair")) {

					ArrayList<ItemStack> items = new ArrayList<ItemStack>();
					ArrayList<String> results = new ArrayList<String>();

					for (ItemStack item : inventory.getContents()) {

						if (item != null) {

							ItemMeta meta = item.getItemMeta();

							if (meta.getDisplayName() != null) {

								if (meta.getDisplayName() != "") {
									String result[] = isInappropriate(meta
											.getDisplayName().toLowerCase(),
											player.getDisplayName());

									if (!result[0].equals("")
											&& !noWarn.contains(player)) {
										items.add(item);
										results.add(result[1]);
										meta.setDisplayName("invalid");
									}
								}
							}
						}
					}

					int counter = 0;
					String words = "";
					for (ItemStack bannedItem : items) {
						player.getInventory().remove(bannedItem);
						words = words.concat(results.get(counter));
						counter++;
					}

					if (counter > 0) {

						sendSevereToConsole("[REPAIR]".concat(player.getName())
								.concat(": ").concat(words));

						if ((firstTimers.containsKey(player.getName()) && firstTimeMax > -1)) {
							// player.updateInventory() ;
							addWarning(player.getName(), words);
						}
					}
				}
			}
		}
	}

	@EventHandler
	public void onInventoryClick(PlayerDropItemEvent event) {

		// sendWarningToConsole(event.getItem().toString());
		String player = event.getPlayer().getName();

		ItemStack thisItem = event.getItemDrop().getItemStack();

		if (thisItem != null) {

			if (thisItem.getType().equals(Material.WRITTEN_BOOK)
					|| thisItem.getType().equals(Material.BOOK_AND_QUILL)) {

				boolean warn = false;
				StringBuilder warnings = new StringBuilder();
				book Book = new book(thisItem);

				if (Book.getTitle() != null) {

					String[] title = isInappropriate(Book.getTitle(), player);
					if (!title[0].isEmpty()) {

						Book.setTitle(title[0]);
						if (title[2].equals("warn")) {
							warnings.append(title[1]);
							warnings.append(" ");
							warn = true;
						}
					}
				}

				ArrayList<String> pages = new ArrayList<String>();

				for (String s : Book.getPages()) {

					String[] lines = s.split("\n");
					ArrayList<String> newlines = new ArrayList<String>();

					for (String l : lines) {

						String[] result = isInappropriate(l, player);
						if (!result[0].equals("")) {
							newlines.add(result[0]);
							if (result[2].equals("warn")) {
								warnings.append(result[1]);
								warnings.append(" ");
								warn = true;
							}
						} else {
							newlines.add(l);
						}
					}

					StringBuilder page = new StringBuilder();
					for (String n : newlines) {
						page.append(n);
						page.append("\n");
					}

					pages.add(page.toString());
				}

				if (warn) {

					sendSevereToConsole("[BOOK]".concat(player).concat(": ")
							.concat(warnings.toString()));

					if (Book.getAuthor() != null) {
						if (!noWarn.contains(Book.getAuthor())) {
							addWarning(Book.getAuthor(), warnings.toString());
						} else if (noWarn.contains(Book.getAuthor())) {
							if (allowReport) {

								String review = lastWord.get(player);

								sendToPlayer(ChatColor.WHITE + "Type "
										+ ChatColor.YELLOW + "/ns report"
										+ ChatColor.WHITE + " to flag "
										+ review + " for review.", player);

								if (lastWord.containsKey(Book.getAuthor())) {
									lastWord.remove(Book.getAuthor());
									lastWord.put(Book.getAuthor(),
											warnings.toString());
								} else {
									lastWord.put(Book.getAuthor(),
											warnings.toString());
								}
							}
						}
					} else {

						if (!noWarn.contains(player)) {
							addWarning(Book.getAuthor(), warnings.toString());
						} else if (noWarn.contains(player)) {
							if (allowReport) {

								String review = lastWord.get(player);

								sendToPlayer(ChatColor.WHITE + "Type "
										+ ChatColor.YELLOW + "/ns report"
										+ ChatColor.WHITE + " to flag "
										+ review + " for review.", player);

								if (lastWord.containsKey(player)) {
									lastWord.remove(player);
									lastWord.put(player, warnings.toString());
								} else {
									lastWord.put(player, warnings.toString());
								}
							}
						}
					}
				}

				Book.setPages(pages);
				event.getItemDrop().getItemStack().setItemMeta(Book.getMeta());
			}
		}
	}

	/*
	 * @EventHandler public void onInventoryClick(PlayerInteractEvent event) {
	 * 
	 * // sendWarningToConsole(event.getItem().toString()); String player =
	 * event.getPlayer().getName();
	 * 
	 * ItemStack thisItem = event.getItem();
	 * 
	 * if (thisItem != null) {
	 * 
	 * if (thisItem.getType().equals(Material.WRITTEN_BOOK) ||
	 * thisItem.getType().equals(Material.BOOK_AND_QUILL)) {
	 * 
	 * boolean warn = false; StringBuilder warnings = new StringBuilder(); book
	 * Book = new book(thisItem);
	 * 
	 * if (Book.getTitle() != null) {
	 * 
	 * String[] title = isInappropriate(Book.getTitle(), player); if
	 * (!title[0].isEmpty()) {
	 * 
	 * Book.setTitle(title[0]); if (title[2].equals("warn")) {
	 * warnings.append(title[1]); warnings.append(" "); warn = true; } } }
	 * 
	 * ArrayList<String> pages = new ArrayList<String>();
	 * 
	 * for (String s : Book.getPages()) {
	 * 
	 * String[] lines = s.split("\n"); ArrayList<String> newlines = new
	 * ArrayList<String>();
	 * 
	 * for (String l : lines) {
	 * 
	 * String[] result = isInappropriate(l, player); if (!result[0].equals(""))
	 * { newlines.add(result[0]); if (result[2].equals("warn")) {
	 * warnings.append(result[1]); warnings.append(" "); warn = true; } } else {
	 * newlines.add(l); } }
	 * 
	 * StringBuilder page = new StringBuilder(); for (String n : newlines) {
	 * page.append(n); page.append("\n"); }
	 * 
	 * pages.add(page.toString());
	 * 
	 * }
	 * 
	 * if (warn) {
	 * 
	 * if (Book.getAuthor() != null) { if (!noWarn.contains(Book.getAuthor())) {
	 * addWarning(Book.getAuthor(), warnings.toString()); } } else {
	 * 
	 * addWarning(player, warnings.toString());
	 * 
	 * } }
	 * 
	 * Book.setPages(pages);
	 * 
	 * event.getItem().setItemMeta(Book.getMeta()); } }
	 * 
	 * }
	 */

	public boolean onCommand(CommandSender sender, Command cmd, String label,
			String[] args) {

		boolean perms = true;
		if (args.length > 0) {

			if (args[0].equalsIgnoreCase("warnings")) {

				if (sender instanceof Player) {
					sendToPlayer(getWarningsString(sender.getName()),
							sender.getName());
				} else if (sender instanceof ConsoleCommandSender) {
					sendWarningToConsole(getWarningsString(sender.getName()));
				}

				return true;
			}

			if (args[0].equalsIgnoreCase("report")) {

				if (sender instanceof Player) {

					if (lastWord.containsKey(sender.getName())) {
						String word = lastWord.get(sender.getName());
						sendToPlayer(
								ChatColor.BLUE
										+ word.concat(ChatColor.WHITE
												+ " has been flagged for review"),
								sender.getName());

						if (ReportedWords.containsKey(word)) {
							int count = (Integer) ReportedWords.get(word);
							ReportedWords.remove(word);
							ReportedWords.put(word, ++count);

						} else {
							ReportedWords.put(word, 1);
						}

						saveConfig();

					} else {
						sendToPlayer("No word found to report.",
								sender.getName());
					}

				}

				return true;
			}

			if (args[0].equalsIgnoreCase("add")) {

				if (sender.hasPermission("ns.add") || sender.isOp()) {

					if (args.length > 1) {
						if (!words.containsKey(args[1])) {

							words.put(args[1], 0);

							if (sender instanceof Player) {
								sendToPlayer(
										"Word ".concat(args[1]).concat(
												" added to list."),
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {
								sendWarningToConsole("Word ".concat(
										ChatColor.BLUE + args[1]
												+ ChatColor.WHITE).concat(
										" added to list."));

							}
							saveWords();

							return true;
						}
					} else {
						if (sender instanceof Player) {
							sendToPlayer("/ns add <word>", sender.getName());
						} else if (sender instanceof ConsoleCommandSender) {
							sendWarningToConsole("/ns add <word>");

						}

						return true;
					}

				} else {
					perms = false;
				}
			}

			if (symbols) {
				if (args[0].equalsIgnoreCase("allow")) {

					if (sender.hasPermission("ns.allow") || sender.isOp()) {

						if (args.length > 1) {
							if (!allowList.contains(args[1])) {

								allowList.add(args[1].toLowerCase());

								if (sender instanceof Player) {
									sendToPlayer(
											"Word ".concat(
													ChatColor.BLUE + args[1]
															+ ChatColor.WHITE)
													.concat(" added to allow list."),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {

									sendWarningToConsole("Word "
											.concat(args[1]).concat(
													" added to allow list."));
								}

								saveWords();

								return true;
							} else {

								if (sender instanceof Player) {
									sendToPlayer(
											"Word ".concat(
													ChatColor.BLUE + args[1]
															+ ChatColor.WHITE)
													.concat(" already exists in allow list."),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {

									sendWarningToConsole("Word "
											.concat(args[1])
											.concat(" already exists in allow list."));
								}

								return true;
							}
						} else {

							if (sender instanceof Player) {
								sendToPlayer("/ns allow <word>",
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {

								sendWarningToConsole("/ns allow <word>");
							}

							return true;
						}
					} else {
						perms = false;
					}
				}
			} else {
				if (sender instanceof Player) {
					sendToPlayer(
							"Symbols are not flagged. No need to allow words containing symbols",
							sender.getName());
				} else if (sender instanceof ConsoleCommandSender) {

					sendWarningToConsole("Symbols are not flagged. No need to allow words containing symbols");
				}
				return true;
			}

			if (args[0].equalsIgnoreCase("exempt")) {

				if (sender.hasPermission("ns.exempt") || sender.isOp()) {

					if (args.length > 1) {
						if (this.getServer().getPlayer(args[1]) != null) {

							Player ply = this.getServer().getPlayer(args[1]);

							if (!noWarn.contains(ply.getName())) {

								if (counts.containsKey(ply.getName())) {

									if (finalWarnings
											.containsKey(ply.getName())) {
										finalWarnings.remove(ply.getName());
									}

									counts.remove(ply.getName());
								}
								noWarn.add(ply.getName());

								if (sender instanceof Player) {
									sendToPlayer(
											"Player "
													.concat(ply.getName())
													.concat(" added to exempt list."),
											sender.getName());

								} else if (sender instanceof ConsoleCommandSender) {

									sendWarningToConsole("Player ".concat(
											ply.getName()).concat(
											" added to exempt list."));
								}

								sendToPlayer(
										"You will no longer receive warnings. Exemption created by "
												+ sender.getName(),
										ply.getName());

								return true;
							} else {

								if (sender instanceof Player) {
									sendToPlayer(
											"Player "
													.concat(ply.getName())
													.concat(" already exists in exempt list."),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {
									sendWarningToConsole("Player ".concat(
											ply.getName()).concat(
											" already exists in exempt list."));
								}

								return true;
							}
						} else {

							if (sender instanceof Player) {
								sendToPlayer("Player not found.",
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {
								sendWarningToConsole("Player not found.");
							}

							return true;
						}
					} else {

						if (sender instanceof Player) {
							sendToPlayer("/ns exempt <player>",
									sender.getName());
						} else if (sender instanceof ConsoleCommandSender) {
							sendWarningToConsole("/ns exempt <player>");
						}

						return true;
					}
				} else {
					perms = false;
				}

			}

			if (args[0].equalsIgnoreCase("notexempt")) {

				if (sender.hasPermission("ns.notexempt") || sender.isOp()) {

					if (args.length > 1) {
						if (this.getServer().getPlayer(args[1]) != null) {

							Player ply = this.getServer().getPlayer(args[1]);

							if (noWarn.contains(ply.getName())) {

								noWarn.remove(ply.getName());

								if (sender instanceof Player) {
									sendToPlayer(
											"Player "
													.concat(ply.getName())
													.concat(" deleted from exempt list."),
											sender.getName());

								} else if (sender instanceof ConsoleCommandSender) {

									sendWarningToConsole("Player ".concat(
											ply.getName()).concat(
											" deleted from exempt list."));
								}

								sendToPlayer(
										"Your warning exemption has been canceled by "
												+ sender.getName(),
										ply.getName());

								return true;
							} else {

								if (sender instanceof Player) {
									sendToPlayer(
											"Player "
													.concat(ply.getName())
													.concat(" not found in exempt list."),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {

									sendWarningToConsole("Player ".concat(
											ply.getName()).concat(
											" not found in exempt list."));
								}

								return true;
							}
						} else {

							if (sender instanceof Player) {
								sendToPlayer("Player not found.",
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {

								sendWarningToConsole("Player not found.");
							}

							return true;
						}
					} else {

						if (sender instanceof Player) {
							sendToPlayer("/ns notexempt <player>",
									sender.getName());
						} else if (sender instanceof ConsoleCommandSender) {
							sendWarningToConsole("/ns notexempt <player>");
						}
						return true;
					}
				} else {
					perms = false;
				}
			}

			if (args[0].equalsIgnoreCase("review")) {
				if (sender.hasPermission("ns.review") || sender.isOp()) {

					int counter = 0;
					for (String s : ReportedWords.keySet()) {

						if (sender instanceof Player) {
							sendToPlayer(String.valueOf(counter).concat(": ")
									+ ChatColor.BLUE + s, sender.getName());
						} else {
							sendWarningToConsole(String.valueOf(counter)
									.concat(": ") + s);
						}
						counter = counter + 1;
					}
					if (ReportedWords.size() > 0) {
						if (sender instanceof Player) {
							sendToPlayer("Use" + ChatColor.BLUE
									+ " /ns remove <word>" + ChatColor.WHITE
									+ " to remove a player request.",
									sender.getName());
						} else {
							sendWarningToConsole("Use" + ChatColor.BLUE
									+ " /ns remove <word>" + ChatColor.WHITE
									+ " to remove a player request.");
						}
					} else {

						if (sender instanceof Player) {
							sendToPlayer("Nothing to show", sender.getName());
						} else {
							sendWarningToConsole("Nothing to show");
						}
					}
					return true;
				} else {
					perms = false;
				}
			}

			if (args[0].equalsIgnoreCase("remove")) {
				if (args.length > 1) {
					if (sender.hasPermission("ns.remove") || sender.isOp()) {
						if (ReportedWords.containsKey(args[1])) {
							ReportedWords.remove(args[1]);
							sendToPlayer(args[1].concat(" was deleted."),
									sender.getName());

							saveWords();

						} else {
							sendToPlayer(args[1].concat(" not found."),
									sender.getName());
						}
					} else {
						perms = false;
					}
				} else {
					sendToPlayer("Use" + ChatColor.BLUE + " /ns remove <word>",
							sender.getName());
				}
				return true;
			}

			if (args[0].equalsIgnoreCase("removeall")) {
				if (sender.hasPermission("ns.remove") || sender.isOp()) {
					ReportedWords.clear();
					if (sender instanceof Player) {
						sendToPlayer(" All player requests removed.",
								sender.getName());
					} else {
						sendWarningToConsole(" All player requests removed.");
					}
				}
				return true;
			}

			if (args[0].equalsIgnoreCase("clear")) {

				if (sender.hasPermission("ns.clear") || sender.isOp()) {

					Player myPly = null;

					if (args.length > 1) {
						if (this.getServer().getPlayer(args[1]) != null) {

							myPly = this.getServer().getPlayer(args[1]);

							if (counts.containsKey(myPly.getName())) {

								if (finalWarnings.containsKey(myPly.getName())) {
									finalWarnings.remove(myPly.getName());
								}

								counts.remove(myPly.getName());

								if (sender instanceof Player) {
									sendToPlayer(
											args[1].concat(" removed from list."),
											sender.getName());

								} else if (sender instanceof ConsoleCommandSender) {
									sendWarningToConsole(args[1]
											.concat(" removed from list."));
								}
								sendToPlayer("Your warnings have been reset.",
										myPly.getName());

							} else {

								if (sender instanceof Player) {
									sendToPlayer(
											args[1].concat(" not found in list."),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {
									sendWarningToConsole(args[1]
											.concat(" not found in list."));
								}
							}
							return true;
						}
					} else {

						if (sender instanceof Player) {
							sendToPlayer("/ns clear <word>", sender.getName());
						} else if (sender instanceof ConsoleCommandSender) {
							sendWarningToConsole("/ns clear <word>");
						}
					}
				} else {
					perms = false;
				}
			}

			if (args[0].equalsIgnoreCase("warn")) {
				if (sender.hasPermission("ns.delete") || sender.isOp()) {
					if (args.length > 1) {
						Player ply = Bukkit.getPlayer(args[1]);

						if (ply != null) {

							StringBuilder s = new StringBuilder();

							if (args.length > 2) {
								for (int a = 2; a < args.length; a++) {
									s.append(args[a].concat(" "));
								}
							}

							if (s.length() > 0) {
								addWarning(ply.getName(), s.toString());
							} else {
								addWarning(ply.getName(),
										"Warned by ".concat(sender.getName()));
							}

							if (sender instanceof Player) {
								sendToPlayer(
										ply.getName().concat(
												" has been warned."),
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {
								sendWarningToConsole(ply.getName().concat(
										" has been warned."));
							}
							return true;
						}
					} else {
						if (sender instanceof Player) {
							sendToPlayer("/ns warn <online player> <reason>",
									sender.getName());
						} else if (sender instanceof ConsoleCommandSender) {
							sendWarningToConsole("/ns warn <player> <reason>* Optional");
						}
					}
				} else {
					perms = false;
				}
			}

			if (args[0].equalsIgnoreCase("delete")) {

				if (sender.hasPermission("ns.delete") || sender.isOp()) {

					if (args.length > 1) {
						if (words.containsKey(args[1])) {

							words.remove(args[1]);

							if (sender instanceof Player) {
								sendToPlayer(
										args[1].concat(" deleted from banned list."),
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {
								sendWarningToConsole(args[1]
										.concat(" deleted from banned list."));
							}
							saveWords();

						} else {

							String Result = "";
							boolean aResult = false;

							for (String key : words.keySet()) {

								String newKey = String.valueOf(key);
								newKey = newKey.replaceAll("/b", "")
										.replaceAll("/i", "");
								if (args[1].equalsIgnoreCase(newKey)) {
									Result = Result.concat(key).concat("\n");
									aResult = true;
								}
							}

							if (!aResult) {
								if (sender instanceof Player) {
									sendToPlayer(
											args[1].concat(" not found in banned list."),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {
									sendWarningToConsole(args[1]
											.concat(" not found in banned list."));
								}
							} else {
								if (sender instanceof Player) {
									sendToPlayer(
											"Possible matches: ".concat(Result),
											sender.getName());
								} else if (sender instanceof ConsoleCommandSender) {
									sendWarningToConsole("Possible matches: "
											.concat(Result));
								}
							}

						}

						if (allowList.contains(args[1])) {

							allowList.remove(args[1]);

							if (sender instanceof Player) {
								sendToPlayer(
										args[1].concat(" deleted from allow list."),
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {
								sendWarningToConsole(args[1]
										.concat(" deleted from allow list."));
							}

							saveWords();

						} else {

							if (sender instanceof Player) {
								sendToPlayer(
										args[1].concat(" not found in allow list."),
										sender.getName());
							} else if (sender instanceof ConsoleCommandSender) {
								sendWarningToConsole(args[1]
										.concat(" not found in allow list."));
							}
						}
						return true;
					}

					else {

						if (sender instanceof Player) {
							sendToPlayer("/ns warn <word>", sender.getName());
						} else if (sender instanceof ConsoleCommandSender) {
							sendWarningToConsole("/ns delete <word>");
						}
					}

				} else {
					perms = false;
				}
			}

			if (args[0].equalsIgnoreCase("info")) {

				sendToPlayer(
						pdfFile.getName() + " version " + pdfFile.getVersion()
								+ "\nCreated by Scott Merryfield"
								+ "\nCurrent word database: " + wordCount
								+ " words." + "\nFinal warning action: "
								+ onFinalWarning + "\n \nCommands:\n"
								+ ChatColor.BLUE + "/ns warnings"
								+ ChatColor.WHITE + " See your warnings."
								+ ChatColor.BLUE + "/ns report"
								+ ChatColor.WHITE
								+ " Report your last flagged word."
								+ ChatColor.BLUE + "/ns info" + ChatColor.WHITE
								+ " This dialog.", sender.getName());

				return true;
			}
		}

		if (!perms) {
			sendToPlayer(
					ChatColor.RED
							+ " You don't have permission for this. /ns "
									.concat(args[0]),
					sender.getName());
			return true;
		}

		return false;
	}

	private void sendToPlayer(final String msg, String player) {
		final Player thisPlayer = Bukkit.getPlayer(player);

		if (thisPlayer != null) {
			if (thisPlayer.isOnline()) {

				Bukkit.getScheduler().scheduleSyncDelayedTask(this,
						new Runnable() {
							public void run() {

								thisPlayer.sendMessage(ChatColor.YELLOW + "["
										+ pdfFile.getName() + "] "
										+ ChatColor.WHITE + msg);
							}
						}, 10L);
			}
		}
	}

	// Subroutine to send data to the console in the correct format.
	/*
	 * private void sendToConsole(String msg) {
	 * 
	 * // Append the name of the plugin to the msg and send to console.
	 * logger.info("[" + pdfFile.getName() + "] " + msg);
	 * 
	 * }
	 */

	private void sendToAll(final String msg) {

		for (Player player : Bukkit.getServer().getOnlinePlayers()) {
			sendToPlayer(msg, player.getName());
		}

	}

	// Subroutine to send data to the console in the correct format.
	private void sendWarningToConsole(String msg) {

		// Append the name of the plugin to the msg and send to console.
		logger.warning("[" + pdfFile.getName() + "] " + msg);

	}

	// Subroutine to send data to the console in the correct format.
	private void sendSevereToConsole(String msg) {

//		if (ignoreOps) {
//			for (Player ply : Bukkit.getOnlinePlayers()) {
//				if (ply.isOp()) {
//					sendToPlayer(ChatColor.RED + msg, ply.getName());
//				}
//			}
//		}

		// Append the name of the plugin to the msg and send to console.
		logger.severe("[" + pdfFile.getName() + "] " + msg);

	}

}
